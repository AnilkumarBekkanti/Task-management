from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # This includes the Django admin panel
    path('api/', include('tasks.urls')),  # Include your app-specific URLs
]


