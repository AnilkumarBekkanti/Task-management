```
Email address: admin
Error: Enter a valid email address.
Email address: admin@ad.com
Password: admin
Password (again): admin
The password is too similar to the username.
This password is too short. It must contain at least 8 characters.
This password is too common.
Bypass password validation and create user anyway? [y/N]: y
Bypass password validation and create user anyway? [y/N]: y
Superuser created successfully.
```